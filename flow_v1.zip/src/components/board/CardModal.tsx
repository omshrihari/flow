'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { updateCard, deleteCard } from '@/actions/cards'
import { getAttachments, uploadAttachment, deleteAttachment } from '@/actions/attachments'
import { toast } from 'sonner'
import { 
  AlignLeft, 
  Paperclip, 
  Trash2, 
  X, 
  Plus,
  FileText, 
  Download,
  Loader2,
  Clock
} from 'lucide-react'
import { format } from 'date-fns'

interface CardModalProps {
  card: any
  isOpen: boolean
  onClose: () => void
  onUpdate: (updatedCard: any) => void
  onDelete: (cardId: string) => void
  role: "owner" | "editor" | "viewer"
}

export function CardModal({ card, isOpen, onClose, onUpdate, onDelete, role }: CardModalProps) {
  const [title, setTitle] = useState(card?.title || '')
  const [description, setDescription] = useState(card?.description || '')
  const [isEditingDescription, setIsEditingDescription] = useState(false)
  const [attachments, setAttachments] = useState<any[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [isLoadingAttachments, setIsLoadingAttachments] = useState(false)

  const canEdit = role === "owner" || role === "editor"

  useEffect(() => {
    if (isOpen && card) {
      setTitle(card.title)
      setDescription(card.description || '')
      fetchAttachments()
    }
  }, [isOpen, card])

  const fetchAttachments = async () => {
    if (!card) return
    setIsLoadingAttachments(true)
    const data = await getAttachments(card.id)
    setAttachments(data)
    setIsLoadingAttachments(false)
  }

  const handleUpdate = async (updates: any) => {
    const result = await updateCard(card.id, updates)
    if (result.error) {
      toast.error(result.error)
    } else {
      onUpdate(result.data)
      toast.success('Card updated!')
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    const formData = new FormData()
    formData.append('file', file)

    const result = await uploadAttachment(card.id, formData)
    if (result.error) {
      toast.error(result.error)
    } else {
      setAttachments([result.data, ...attachments])
      toast.success('File uploaded!')
    }
    setIsUploading(false)
  }

  const handleDeleteAttachment = async (id: string, filePath: string) => {
    const result = await deleteAttachment(id, filePath)
    if (result.error) {
      toast.error(result.error)
    } else {
      setAttachments(attachments.filter(a => a.id !== id))
      toast.success('Attachment removed')
    }
  }

  if (!card) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white dark:bg-slate-900 overflow-hidden flex flex-col max-h-[90vh]">
        <DialogHeader className="px-6 pt-6">
          <div className="flex items-start gap-4">
            <FileText className="h-6 w-6 mt-1 text-slate-500" />
            <div className="flex-1">
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onBlur={() => title !== card.title && handleUpdate({ title })}
                disabled={!canEdit}
                className="w-full bg-transparent text-xl font-bold focus:bg-white dark:focus:bg-slate-800 px-1 py-0.5 rounded outline-none ring-primary disabled:cursor-default"
              />
              <p className="text-sm text-muted-foreground mt-1">
                in list <span className="underline cursor-pointer">{card.list_title || 'List'}</span>
              </p>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-8 custom-scrollbar">
          {/* Description Section */}
          <section className="space-y-3">
            <div className="flex items-center gap-3 text-slate-900 dark:text-slate-100 font-semibold">
              <AlignLeft className="h-5 w-5" />
              <h3>Description</h3>
              {!isEditingDescription && description && canEdit && (
                <Button variant="ghost" size="sm" onClick={() => setIsEditingDescription(true)}>
                  Edit
                </Button>
              )}
            </div>
            {isEditingDescription ? (
              <div className="space-y-2">
                <textarea
                  autoFocus
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Add a more detailed description..."
                  className="w-full min-h-[120px] p-3 rounded-lg border bg-slate-50 dark:bg-slate-800 outline-none focus:ring-2 focus:ring-blue-600 transition-all"
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => {
                    handleUpdate({ description })
                    setIsEditingDescription(false)
                  }}>Save</Button>
                  <Button variant="ghost" size="sm" onClick={() => setIsEditingDescription(false)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <div 
                onClick={() => canEdit && setIsEditingDescription(true)}
                className={description ? "text-sm text-slate-700 dark:text-slate-300 leading-relaxed cursor-pointer" : "bg-slate-100 dark:bg-slate-800/50 p-4 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors text-sm text-muted-foreground"}
              >
                {description || (canEdit ? "Add a more detailed description..." : "No description provided.")}
              </div>
            )}
          </section>

          {/* Attachments Section */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 text-slate-900 dark:text-slate-100 font-semibold">
                <Paperclip className="h-5 w-5" />
                <h3>Attachments</h3>
              </div>
              {canEdit && (
                <div className="relative">
                  <input
                    type="file"
                    id="file-upload"
                    className="hidden"
                    onChange={handleFileUpload}
                    disabled={isUploading}
                  />
                  <label 
                    htmlFor="file-upload"
                    className="inline-flex cursor-pointer items-center gap-2 rounded-md bg-slate-100 dark:bg-slate-800 px-3 py-1.5 text-xs font-medium hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                    {isUploading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
                    Add
                  </label>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 gap-3">
              {isLoadingAttachments ? (
                 <div className="flex justify-center p-4"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
              ) : attachments.length > 0 ? (
                attachments.map((file) => (
                  <div key={file.id} className="group flex items-center gap-4 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border transition-all">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
                      {file.type.startsWith('image/') ? (
                        <img src={file.url} alt="" className="h-full w-full object-cover rounded-lg" />
                      ) : (
                        <FileText className="h-6 w-6" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{file.name}</p>
                      <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-2">
                        <span>{format(new Date(file.created_at), 'MMM d, yyyy')}</span>
                        <span>•</span>
                        <span>{(file.size / 1024).toFixed(1)} KB</span>
                      </p>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <a href={file.url} target="_blank" rel="noopener noreferrer">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-blue-600">
                          <Download className="h-4 w-4" />
                        </Button>
                      </a>
                      {canEdit && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-red-600"
                          onClick={() => handleDeleteAttachment(file.id, file.file_path)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground italic pl-8">No attachments yet.</p>
              )}
            </div>
          </section>
        </div>

        <div className="p-6 border-t bg-slate-50 dark:bg-slate-900/50 flex justify-between items-center">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              Created {format(new Date(card.created_at), 'PPP')}
            </div>
            {canEdit && (
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={() => {
                  if(confirm('Delete this card?')) {
                    onDelete(card.id)
                    onClose()
                  }
                }}
                className="font-bold rounded-lg"
              >
                Delete Card
              </Button>
            )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
