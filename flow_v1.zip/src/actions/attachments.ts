'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'

export async function getAttachments(cardId: string) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('attachments')
    .select('*')
    .eq('card_id', cardId)
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching attachments:', error)
    return []
  }

  return data
}

export async function uploadAttachment(cardId: string, formData: FormData) {
  const supabase = await createClient()
  const file = formData.get('file') as File
  if (!file) return { error: 'No file provided' }

  const filePath = `${cardId}/${Date.now()}-${file.name}`
  
  const { data: uploadData, error: uploadError } = await supabase.storage
    .from('attachments')
    .upload(filePath, file)

  if (uploadError) {
    console.error('Storage upload error:', uploadError)
    return { error: `Upload failed: ${uploadError.message}` }
  }

  const { data: { publicUrl } } = supabase.storage
    .from('attachments')
    .getPublicUrl(filePath)

  const { data, error } = await supabase
    .from('attachments')
    .insert([
      {
        card_id: cardId,
        name: file.name,
        url: publicUrl,
        file_path: filePath,
        type: file.type,
        size: file.size,
      },
    ])
    .select()
    .single()

  if (error) {
    console.error('Database attachment error:', error)
    return { error: `Database error: ${error.message}` }
  }

  return { data }
}

export async function deleteAttachment(id: string, filePath: string) {
  const supabase = await createClient()
  
  const { error: storageError } = await supabase.storage
    .from('attachments')
    .remove([filePath])

  if (storageError) {
    console.error('Storage remove error:', storageError)
  }

  const { error } = await supabase
    .from('attachments')
    .delete()
    .eq('id', id)

  if (error) {
    console.error('Error deleting attachment row:', error)
    return { error: error.message }
  }

  return { error: null }
}
